# Cola de Producción Placas

App web para visualizar y controlar una cola de producción en tiempo real.